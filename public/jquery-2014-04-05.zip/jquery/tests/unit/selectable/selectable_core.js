/*
 * selectable_core.js
 */